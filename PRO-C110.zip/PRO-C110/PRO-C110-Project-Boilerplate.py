import cv2
import numpy as np
import tensorflow as tf

# Load the pre-trained model
model = tf.keras.models.load_model('keras_model.h5')

# Open the webcam (index 0)
camera = cv2.VideoCapture(0)

while True:
    # Read a frame from the camera
    status, frame = camera.read()

    # Check if the frame was successfully read
    if not status:
        break

    # Flip the frame horizontally (optional)
    frame = cv2.flip(frame, 1)

    # Resize the frame to the required input size of the model
    img = cv2.resize(frame, (224, 224))

    # Expand the dimensions to match the model's input shape (batch_size, height, width, channels)
    test_image = np.expand_dims(img, axis=0)

    # Normalize the frame (scaling pixel values to a range of 0 to 1)
    normalized_image = test_image / 255.0

    # Get predictions from the model
    prediction = model.predict(normalized_image)

    # Assuming your model has 3 classes (Rock, Paper, Scissors), you can interpret the prediction as follows:
    # argmax() gives the index of the class with the highest probability
    class_index = np.argmax(prediction)
    classes = ['Rock', 'Paper', 'Scissors']
    gesture = classes[class_index]

    # Display the gesture prediction on the frame
    cv2.putText(frame, gesture, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

    # Show the frame with the prediction
    cv2.imshow("Result", frame)

    # Display the original frame
    cv2.imshow('Feed', frame)

    # Wait for 1ms and check for key press (break the loop if 'space' key is pressed)
    code = cv2.waitKey(1)
    if code == 32:
        break

# Release the camera and close the windows
camera.release()
cv2.destroyAllWindows()